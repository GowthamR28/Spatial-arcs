import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { useFlowStore } from '../store/useFlowStore';
import { ease, lerp, nodePos, controlPoint, quadPoint } from '../lib/layout';
import type { FlowEdge, FlowNode, Particle } from '../lib/types';

interface TooltipState {
  visible: boolean;
  x: number;
  y: number;
  name: string;
  demand: number;
}

// However high the user pushes the topN slider, only this many edges get an
// animated particle. All edges still get their static arc/line drawn — this
// just caps the per-frame gradient/sprite draw calls, which is what actually
// costs time, not the line strokes themselves.
const PARTICLE_EDGE_CAP = 1500;

// Sprite cache: instead of calling ctx.createRadialGradient() for every
// particle on every frame (the original code's actual freeze cause — 50k-100k
// gradient allocations, 60x/sec, all on the main thread), we pre-render a
// bounded set of glow sprites onto small offscreen canvases, keyed by a
// quantized color+radius, and just drawImage() them. Color and radius are
// both continuous, so we snap each to a coarse bucket — this keeps the cache
// to a few hundred entries max no matter how many particles are on screen.
function quantize(v: number, min: number, max: number, buckets: number): number {
  if (max === min) return min;
  const t = Math.min(1, Math.max(0, (v - min) / (max - min)));
  const q = Math.round(t * (buckets - 1)) / (buckets - 1);
  return min + q * (max - min);
}

function makeGlowSprite(color: string, radius: number): HTMLCanvasElement {
  const size = Math.ceil(radius * 2) + 2;
  const sprite = document.createElement('canvas');
  sprite.width = size;
  sprite.height = size;
  const sctx = sprite.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;
  const glow = sctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
  glow.addColorStop(0, color);
  glow.addColorStop(1, 'rgba(255,255,255,0)');
  sctx.fillStyle = glow;
  sctx.beginPath();
  sctx.arc(cx, cy, radius, 0, Math.PI * 2);
  sctx.fill();
  return sprite;
}

export function FlowCanvas({ onHover }: { onHover: (t: TooltipState) => void }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);

  // Mutable refs mirroring store, updated on every change but read inside rAF
  // loop without forcing React re-renders (canvas is imperative for perf).
  const modeRef = useRef(useFlowStore.getState().mode);
  const fromModeRef = useRef(useFlowStore.getState().mode);
  const transStartRef = useRef(performance.now());
  const hoverNodeRef = useRef<FlowNode | null>(null);
  const currentBlendRef = useRef(0);
  const visibleEdgesRef = useRef<FlowEdge[]>([]);
  const visibleNodesRef = useRef<FlowNode[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const valueDomainRef = useRef<[number, number]>([0, 1]);
  const spriteCacheRef = useRef<Map<string, HTMLCanvasElement>>(new Map());

  // Pan/zoom, like an actual map — positions are transformed at draw time,
  // radii/line-widths/font sizes are NOT scaled with zoom. That's what makes
  // zooming in actually declutter a dense cluster: node spacing grows while
  // the bubbles themselves stay a constant screen size.
  const viewRef = useRef({ scale: 1, tx: 0, ty: 0 });
  const draggingRef = useRef(false);

  function toScreen(p: { x: number; y: number }) {
    const v = viewRef.current;
    return { x: p.x * v.scale + v.tx, y: p.y * v.scale + v.ty };
  }

  const transDuration = 900;

  // Recompute visible edges + visible nodes + particles whenever relevant
  // store slices change (topN, dataset, filter). NOT done per animation frame.
  useEffect(() => {
    const recompute = () => {
      const { nodes, edgesRaw, topN, scales } = useFlowStore.getState();
      const n = Math.min(topN, edgesRaw.length);
      const sliced = edgesRaw.slice(0, n);

      const edges: FlowEdge[] = [];
      const nodeSet = new Map<string, FlowNode>();
      for (const e of sliced) {
        const s = nodes.get(e.sourceId);
        const t = nodes.get(e.targetId);
        if (!s || !t) continue;
        edges.push({ ...e, s, t });
        nodeSet.set(s.id, s);
        nodeSet.set(t.id, t);
      }
      visibleEdgesRef.current = edges;
      // Only draw stops that actually appear in the currently visible route
      // set — this is what stops the bubble pile-up when topN is capped:
      // previously every node in the whole dataset was drawn regardless of
      // how many edges were actually shown.
      visibleNodesRef.current = Array.from(nodeSet.values());

      const domain = scales.widthScale.domain();
      valueDomainRef.current = [domain[0], domain[domain.length - 1]];

      const particles: Particle[] = [];
      const particleEdgeCount = Math.min(edges.length, PARTICLE_EDGE_CAP);
      for (let i = 0; i < particleEdgeCount; i++) {
        const e = edges[i];
        const count = e.value > valueDomainRef.current[1] * 0.4 ? 2 : 1;
        for (let k = 0; k < count; k++) {
          particles.push({ edgeIndex: i, t: Math.random(), speed: 0.09 + Math.random() * 0.1 });
        }
      }
      particlesRef.current = particles;
      spriteCacheRef.current.clear();
    };

    recompute();
    const unsub = useFlowStore.subscribe(recompute);
    return unsub;
  }, []);

  // Watch mode changes to trigger the arc<->geo morph transition, and reset
  // pan/zoom whenever a genuinely new dataset comes in (not on topN/filter
  // tweaks — those shouldn't yank the user's view around).
  useEffect(() => {
    const unsub = useFlowStore.subscribe((state, prev) => {
      if (state.mode !== prev.mode) {
        fromModeRef.current = prev.mode;
        modeRef.current = state.mode;
        transStartRef.current = performance.now();
      }
      if (state.edgesRaw !== prev.edgesRaw) {
        viewRef.current = { scale: 1, tx: 0, ty: 0 };
      }
    });
    return unsub;
  }, []);

  // Resize handling
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;

    function resize() {
      const wrap = wrapRef.current!;
      const W = wrap.clientWidth;
      const H = wrap.clientHeight;
      const DPR = Math.min(window.devicePixelRatio || 1, 3);
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = W + 'px';
      canvas.style.height = H + 'px';
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      useFlowStore.getState().setCanvasSize(W, H);
    }
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  // Main render loop
  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    let lastTime = performance.now();

    function getSprite(color: string, radius: number): HTMLCanvasElement {
      const rq = Math.round(radius * 2) / 2; // 0.5px buckets
      const key = color + '|' + rq;
      let sprite = spriteCacheRef.current.get(key);
      if (!sprite) {
        sprite = makeGlowSprite(color, rq);
        spriteCacheRef.current.set(key, sprite);
      }
      return sprite;
    }

    function drawLabel(
      ctx2: CanvasRenderingContext2D,
      text: string,
      x: number,
      y: number,
      dx: number,
      dy: number,
      align: CanvasTextAlign,
      angle: number,
      bold: boolean,
      color: string
    ) {
      ctx2.save();
      ctx2.translate(x + dx, y + dy);
      if (angle) ctx2.rotate(angle);
      ctx2.font = (bold ? '600 11px' : '500 10px') + " 'Inter', sans-serif";
      ctx2.textAlign = align;
      ctx2.fillStyle = color;
      ctx2.fillText(text, 0, 0);
      ctx2.restore();
    }

    function draw(now: number) {
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const { filterText, scales, mode } = useFlowStore.getState();
      const wrap = wrapRef.current!;
      const W = wrap.clientWidth;
      const H = wrap.clientHeight;

      const progress = Math.min((now - transStartRef.current) / transDuration, 1);
      const easedProgress = ease(progress);
      const fromBlend = fromModeRef.current === 'geo' ? 1 : 0;
      const toBlend = modeRef.current === 'geo' ? 1 : 0;
      const blend = lerp(fromBlend, toBlend, easedProgress);
      currentBlendRef.current = blend;
      if (progress >= 1) fromModeRef.current = modeRef.current;

      ctx.clearRect(0, 0, W, H);

      const highlight = filterText.trim().toLowerCase();
      const hoverId = hoverNodeRef.current ? hoverNodeRef.current.id : null;
      const visibleEdges = visibleEdgesRef.current;
      const [vMin, vMax] = valueDomainRef.current;

      ctx.lineCap = 'round';

      // edges
      visibleEdges.forEach((e) => {
        const p0 = toScreen(nodePos(e.s, blend));
        const p1 = toScreen(nodePos(e.t, blend));
        const c = controlPoint(p0, p1, blend);
        const isHot = hoverId && (e.sourceId === hoverId || e.targetId === hoverId);
        const isSearchHit =
          highlight && (e.s.name.toLowerCase().includes(highlight) || e.t.name.toLowerCase().includes(highlight));
        const dim = hoverId && !isHot;
        ctx.beginPath();
        ctx.moveTo(p0.x, p0.y);
        ctx.quadraticCurveTo(c.x, c.y, p1.x, p1.y);
        ctx.strokeStyle = scales.colorScale(e.value);
        ctx.globalAlpha = dim ? 0.06 : isHot || isSearchHit ? 1 : 0.55;
        ctx.lineWidth = scales.widthScale(e.value);
        ctx.stroke();
      });
      ctx.globalAlpha = 1;

      // particles — sprite-cached, no gradient allocation in this loop
      particlesRef.current.forEach((pt) => {
        const e = visibleEdges[pt.edgeIndex];
        if (!e) return;
        pt.t += pt.speed * dt;
        if (pt.t > 1) pt.t -= 1;
        const p0 = toScreen(nodePos(e.s, blend));
        const p1 = toScreen(nodePos(e.t, blend));
        const c = controlPoint(p0, p1, blend);
        const pos = quadPoint(p0, c, p1, pt.t);
        const fade = Math.sin(Math.PI * pt.t);
        const dim = hoverId && !(e.sourceId === hoverId || e.targetId === hoverId);
        const r = 2.2 + scales.widthScale(e.value) * 0.55;
        const qValue = quantize(e.value, vMin, vMax, 24);
        const col = scales.colorScale(qValue);
        const alpha = (dim ? 0.12 : 1) * (0.4 + 0.6 * fade);

        const sprite = getSprite(col, r * 3.2);
        ctx.globalAlpha = alpha * 0.75;
        ctx.drawImage(sprite, pos.x - sprite.width / 2, pos.y - sprite.height / 2);

        ctx.globalAlpha = alpha;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, r * 0.55, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      // nodes — only the ones referenced by currently visible edges
      const nodesArr = visibleNodesRef.current;
      nodesArr.forEach((n) => {
        const p = toScreen(nodePos(n, blend));
        const r = scales.radiusScale(n.demand);
        const isHot = hoverId === n.id;
        const isSearchHit = highlight && n.name.toLowerCase().includes(highlight);
        const dim = hoverId && !isHot;
        const col = isSearchHit ? '#0ea5a8' : scales.nodeColorScale(n.demand);

        if (!dim) {
          ctx.globalAlpha = 0.16;
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.arc(p.x, p.y, r * 1.7, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = col;
        ctx.globalAlpha = dim ? 0.18 : 1;
        ctx.fill();
        if (isHot || isSearchHit) {
          ctx.lineWidth = 2.5;
          ctx.strokeStyle = '#ffffff';
          ctx.stroke();
        }
        ctx.globalAlpha = 1;

        // Hover/search always gets a label, live, regardless of the
        // precomputed static layout. Otherwise fall back to the
        // collision-avoided placement computed once in computeLayouts.
        if (isHot || isSearchHit) {
          const ty = mode === 'arc' ? r + 14 : 0;
          const tx = mode === 'arc' ? 0 : r + 6;
          const align: CanvasTextAlign = mode === 'arc' ? 'center' : 'left';
          const text = n.name.length > 26 ? n.name.slice(0, 24) + '…' : n.name;
          drawLabel(ctx, text, p.x, p.y, tx, ty, align, 0, true, '#0b1220');
        } else {
          const label = mode === 'geo' ? n.geoLabel : n.arcLabel;
          if (label?.show) {
            drawLabel(ctx, label.text, p.x, p.y, label.dx, label.dy, label.align, label.angle, false, dim ? 'rgba(107,118,134,0.3)' : '#0b1220');
          }
        }
      });

      rafRef.current = requestAnimationFrame(draw);
    }

    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  // Mouse interaction: hover, wheel-zoom, drag-pan, double-click reset —
  // this is what makes a dense cluster of overlapping stops actually
  // navigable instead of a static wall of bubbles.
  useEffect(() => {
    const canvas = canvasRef.current!;
    let dragStart = { x: 0, y: 0 };
    let viewStart = { tx: 0, ty: 0 };

    function onHoverMove(mx: number, my: number) {
      const { scales } = useFlowStore.getState();
      let found: FlowNode | null = null;
      let best = Infinity;
      visibleNodesRef.current.forEach((n) => {
        const p = toScreen(nodePos(n, currentBlendRef.current));
        const r = scales.radiusScale(n.demand) + 4;
        const d = Math.hypot(mx - p.x, my - p.y);
        if (d < r && d < best) {
          best = d;
          found = n;
        }
      });
      hoverNodeRef.current = found;
      if (found) {
        const f: FlowNode = found;
        onHover({ visible: true, x: mx, y: my, name: f.name, demand: f.demand });
      } else {
        onHover({ visible: false, x: mx, y: my, name: '', demand: 0 });
      }
    }

    function onMove(e: MouseEvent) {
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      if (draggingRef.current) {
        const v = viewRef.current;
        v.tx = viewStart.tx + (e.clientX - dragStart.x);
        v.ty = viewStart.ty + (e.clientY - dragStart.y);
        onHover({ visible: false, x: mx, y: my, name: '', demand: 0 });
        return;
      }
      onHoverMove(mx, my);
    }

    function onLeave() {
      if (!draggingRef.current) hoverNodeRef.current = null;
      onHover({ visible: false, x: 0, y: 0, name: '', demand: 0 });
    }

    function onDown(e: MouseEvent) {
      draggingRef.current = true;
      dragStart = { x: e.clientX, y: e.clientY };
      viewStart = { tx: viewRef.current.tx, ty: viewRef.current.ty };
      hoverNodeRef.current = null;
      canvas.style.cursor = 'grabbing';
    }

    function onUp() {
      draggingRef.current = false;
      canvas.style.cursor = 'grab';
    }

    function onWheel(e: WheelEvent) {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const v = viewRef.current;
      const logX = (mx - v.tx) / v.scale;
      const logY = (my - v.ty) / v.scale;
      const factor = Math.exp(-e.deltaY * 0.0015);
      const newScale = Math.min(10, Math.max(0.5, v.scale * factor));
      viewRef.current = { scale: newScale, tx: mx - logX * newScale, ty: my - logY * newScale };
    }

    function onDblClick() {
      viewRef.current = { scale: 1, tx: 0, ty: 0 };
    }

    canvas.style.cursor = 'grab';
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseleave', onLeave);
    canvas.addEventListener('mousedown', onDown);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('dblclick', onDblClick);
    window.addEventListener('mouseup', onUp);
    return () => {
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('mouseleave', onLeave);
      canvas.removeEventListener('mousedown', onDown);
      canvas.removeEventListener('wheel', onWheel);
      canvas.removeEventListener('dblclick', onDblClick);
      window.removeEventListener('mouseup', onUp);
    };
  }, [onHover]);

  return (
    <div className="canvas-wrap" ref={wrapRef}>
      <canvas ref={canvasRef} />
      <div className="zoom-hint">scroll to zoom · drag to pan · double-click to reset</div>
    </div>
  );
}

export const fmt = d3.format(',');